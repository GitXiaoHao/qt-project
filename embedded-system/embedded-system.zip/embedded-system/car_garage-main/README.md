# car_garage
Qt-车库车牌号识别

开发文档:
https://ai.baidu.com/ai-doc/OCR/ck3h7y191

- 总结:

这个也是用qt,然后调用百度ai开放平台的接口,

然后把我们拍到图片发给百度,

然后百度再返回来,没别的,这个就不再总结太多了
